﻿using System;

namespace BirthYearCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter your age:");
            int age = Convert.ToInt32(Console.ReadLine());

            // Calculate birth year
            int currentYear = DateTime.Now.Year;
            int birthYear = currentYear - age;

            Console.WriteLine($"\nHello {name}, you were born in {birthYear}.");
        }
    }
}

