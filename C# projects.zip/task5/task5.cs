﻿using System;

public class ElectricityBillCalculator
{
    static void Main(string[] args)
    {
        int customerId, consumedUnits;
        double charge, surcharge = 0, grossAmount, netAmount;
        string customerName;

        Console.WriteLine("\nCalculate Electricity Bill:\n");
        Console.WriteLine("----------------------------");

        Console.Write("Input Customer ID: ");
        customerId = Convert.ToInt32(Console.ReadLine());

        Console.Write("Input the name of the customer: ");
        customerName = Console.ReadLine();

        Console.Write("Input the unit consumed by the customer: ");
        consumedUnits = Convert.ToInt32(Console.ReadLine());

        // Determine the charge based on consumed units
        if (consumedUnits < 200)
            charge = 1.20;
        else if (consumedUnits >= 200 && consumedUnits < 400)
            charge = 1.50;
        else if (consumedUnits >= 400 && consumedUnits < 600)
            charge = 1.80;
        else
            charge = 2.00;

        grossAmount = consumedUnits * charge;

        // Calculate surcharge if the gross amount exceeds 300
        if (grossAmount > 300)
            surcharge = grossAmount * 15 / 100.0;

        netAmount = grossAmount + surcharge;

        // Set minimum net amount as 100
        if (netAmount < 100)
            netAmount = 100;

        // Print electricity bill details
        Console.WriteLine("\nElectricity Bill");
        Console.WriteLine($"Customer IDNO: {customerId}");
        Console.WriteLine($"Customer Name: {customerName}");
        Console.WriteLine($"Unit Consumed: {consumedUnits}");
        Console.WriteLine($"Amount Charges @Rs. {charge} per unit: {grossAmount}");
        Console.WriteLine($"Surcharge Amount: {surcharge}");
        Console.WriteLine($"Net Amount Paid By the Customer: {netAmount}");
    }
}
