﻿using System;

public class Task4
{
    public static void Main()
    {
        int p, c, m; 

        Console.WriteLine("Find eligibility for admission:");
        Console.WriteLine("----------------------------------\n");

        Console.WriteLine("Eligibility Criteria:");
        Console.WriteLine("Marks in Maths >= 65");
        Console.WriteLine("Marks in Phy >= 55");
        Console.WriteLine("Marks in Chem >= 50");
        Console.WriteLine("Total in all three subjects >= 180");
        Console.WriteLine("OR Total in Maths and Physics >= 140");
        Console.WriteLine("-------------------------------------\n");

        Console.Write("Input the marks obtained in Physics: ");
        p = Convert.ToInt32(Console.ReadLine());

        Console.Write("Input the marks obtained in Chemistry: ");
        c = Convert.ToInt32(Console.ReadLine());

        Console.Write("Input the marks obtained in Mathematics: ");
        m = Convert.ToInt32(Console.ReadLine());

        int totalMarks = m + p + c;
        int totalMathsPhysics = m + p;

        if (m >= 65 && p >= 55 && c >= 50 && (totalMarks >= 180 || totalMathsPhysics >= 140))
        {
            Console.WriteLine("The candidate is eligible for admission.");
        }
        else
        {
            Console.WriteLine("The candidate is not eligible.");
        }
    }
}
