﻿using System;

public class Project

{
     public static void Main()
    {
        DateTime today = DateTime.Now;

        DateTime answer = today.AddDays(40);

        Console.WriteLine($"Today {today : dddd}");

        Console.WriteLine($"40 days from today:{answer:dddd}");

    }

}