﻿// Task no 13 (structure)
using System;

class Program
{
    // Definition of the employee structure
    struct Employee
    {
        public string Name; // Member to store employee name
        public DateOfBirth BirthDate; // Member to store date of birth (nested structure)
    }

    // Definition of the DateOfBirth structure (nested within the Employee structure)
    struct DateOfBirth
    {
        public int Day; // Member to store day
        public int Month; // Member to store month
        public int Year; // Member to store year
    }

    static void Main(string[] args)
    {
        // Array to store employees
        Employee[] employees = new Employee[2];

        // Loop to input data for multiple employees
        for (int i = 0; i < employees.Length; i++)
        {
            Console.Write("Name of the employee: ");
            employees[i].Name = Console.ReadLine();

            Console.Write("Input day of birth: ");
            employees[i].BirthDate.Day = Convert.ToInt32(Console.ReadLine());

            Console.Write("Input month of birth: ");
            employees[i].BirthDate.Month = Convert.ToInt32(Console.ReadLine());

            Console.Write("Input year of birth: ");
            employees[i].BirthDate.Year = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();
        }

        // Display the stored data
        foreach (var employee in employees)
        {
            Console.WriteLine($"Employee Name: {employee.Name}");
            Console.WriteLine($"Date of Birth: {employee.BirthDate.Day}");

        }
    }
}