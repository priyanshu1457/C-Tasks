﻿using System;

public class AlphabetPattern
{
    public static void Main()
    {
        int height = 7; // Height of the pattern

        // Loop for each row
        for (int row = 0; row < height; row++)
        {
            // Loop for each column
            for (int col = 0; col < height; col++)
            {
                // Print '*' for the top row and the middle column
                if (row == 0 || col == height / 2)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(" ");
                }
            }
            Console.WriteLine(); // Move to the next line after each row
        }
    }
}

