﻿// task no. 11 (Array(String))
using System;

class Task11
{
    static void Main()
    {
        Console.Write("Enter a string: ");
        string input = Console.ReadLine();

        // Convert the string to a character array
        char[] charArray = input.ToCharArray();

        // Sort the character array
        Array.Sort(charArray);

        // Convert the sorted character array back to a string
        string sortedString = new string(charArray);

        Console.WriteLine("Sorted string in ascending order: " + sortedString);
    }
}

