﻿using System;

namespace project

{
    static void Main(string[] args)
    {
        Datetime today = DeteTime.Now;

        Datetime answer = today.AddDays(40);

        Console.WriteLine($ "Today {today : dddd}");

        Console.WriteLine($ "40 days from today:{answer:dddd}");

    }

}