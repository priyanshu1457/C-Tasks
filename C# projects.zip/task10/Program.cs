﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Input the size of the square matrix: ");
        int n = int.Parse(Console.ReadLine());

        int[,] matrix = new int[n, n];
        int sum = 0;

        Console.WriteLine("Input elements in the first matrix:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                Console.Write($"Element [{i},{j}]: ");
                matrix[i, j] = int.Parse(Console.ReadLine());
            }
        }

        for (int i = 0; i < n; i++)
        {
            sum += matrix[i, i];
        }

        Console.WriteLine($"The sum of the right diagonal elements is: {sum}");
    }
}

