﻿// task no. 12 (Method and Fuctions) 
using System;

class Task12
{
    static void Main()
    {
        Console.Write("Inout the number of fibonacci series: ");
        int n = int.Parse(Console.ReadLine());
        DisplayFibonacci(n);
    }

    static void DisplayFibonacci(int n)
    {
        int firstNumber = 0, secondNumber = 1, nextNumber;

        Console.Write("The Fibonacci Series is : ");
        for (int i = 0; i < n; i++)
        {
            if (i == 0)
            {
                Console.Write(firstNumber + " ");
                continue;
            }
            if (i == 1)
            {
                Console.Write(secondNumber + " ");
                continue;
            }
            nextNumber = firstNumber + secondNumber;
            firstNumber = secondNumber;
            secondNumber = nextNumber;

            Console.Write(nextNumber + " ");
        }
    }
}
