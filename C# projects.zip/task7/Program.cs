﻿using System;
class Prishu

{
    static void Main()
    {
        // Input the first term, common ratio, and number of terms
        Console.Write("Enter the first term (a): ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter the common ratio (r): ");
        double r = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter the number of terms (n): ");
        int n = Convert.ToInt32(Console.ReadLine());

        // Calculate the sum of the geometric progression series
        double sum;
        if (r == 1)
        {
            sum = a * n; // Special case when the common ratio is 1
        }
        else
        {
            sum = a * (1 - Math.Pow(r, n)) / (1 - r);
        }

        // Output the result
        Console.WriteLine($"The sum of the geometric progression series is: {sum}");
    }
}
