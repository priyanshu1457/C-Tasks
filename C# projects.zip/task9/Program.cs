﻿//For loop 2nd program
using System;

class Task9
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        int number = Convert.ToInt32(Console.ReadLine());

        for (int i = 1; i <= number; i++)
        {
            int cube = i * i * i;
            Console.WriteLine($"Number is: {i} and cube of {i} is: {cube}");
        }
    }
}

