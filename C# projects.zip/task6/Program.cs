﻿using System;
using System.Text;

class program
{
    static void Main(string[] args)
    {
        Console.Write("Enter the desired password length: ");
        int passwordLength = int.Parse(Console.ReadLine());

        string randomPassword = GenerateRandomPassword(passwordLength);
        Console.WriteLine($"Generated password: {randomPassword}");
    }

    static string GenerateRandomPassword(int length)
    {
        const string charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder password = new StringBuilder(length);
        Random rnd = new Random();

        for (int i = 0; i < length; i++)
        {
            int randomIndex = rnd.Next(charSet.Length);
            password.Append(charSet[randomIndex]);
        }

        return password.ToString();
    }
}
